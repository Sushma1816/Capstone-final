import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm, FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { User } from '../user';
import { subscribeOn } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted = false;
  loading = false;
  loginError: string | undefined;

  today: number = Date.now();

  @Input()
  loginsForm: any = {
    email: '',
    password: '',
  };

  user: User = new User();

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router,
    private formBuilder: FormBuilder,) {

    setInterval(() => { this.today = Date.now() }, 1);
  }

  ngOnInit(): void {

  }

  // userLogin(){
  //   console.log(this.user)
  //   this.userService.loginUser(this.user).subscribe(data=>{
  //     // alert("Login succesfull")
  //     this.router.navigate(['track-detail'])
  //   },(error)=>{ 
  //     console.log(error);
  //     this.loading = false;
  //     this.loginError = "email or password is incorrect";
  // });

  // }

  userLogin() {
    console.log(this.user)
    this.userService.loginUser(this.user).subscribe((result: any) => {

      let data :any = localStorage.setItem("user_id", JSON.stringify(result.email));
      localStorage.setItem("password", result.password);
      this.router.navigate(['track-detail'])
    }, (error) => {
      console.log(error);
      this.loading = false;
      this.loginError = "email or password is incorrect";
    });

  }
  
}


