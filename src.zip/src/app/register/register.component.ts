import { Component, Input, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Input()
  registerDetails: any = {
    email: '',
    password: '',
    repassword: '',
    name: '',
  };

  user: User = new User();
  submitted = false;
  constructor(private userService: UserService,
    private router: Router) { }

  ngOnInit(): void {
  }

  // saveUser() {
  //   this.userService.createUser(this.user).subscribe(data => {
  //     console.log(data);

  //   },
  //     error => console.log(error));
  //   this.router.navigate(['login'])

  // }

  saveUser() {
    this.userService.createUser(this.user).subscribe((username: any) => {
      let data :any = localStorage.setItem("name", JSON.stringify(username.name));
      console.log(data);

    },
      error => console.log(error));
    this.router.navigate(['login'])

  }


  onSubmit() {
    console.log(this.user);
    this.saveUser();

  }


}
