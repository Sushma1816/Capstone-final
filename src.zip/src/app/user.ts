export class User {
    id: any;
    name:any;
    email: any;
    password: any;

    
    
}

export class Product{
    pid: any;
    proName: any;
    shipment: any;
    place: any;
    status: any;
    price:any;
    date:any;
 }
