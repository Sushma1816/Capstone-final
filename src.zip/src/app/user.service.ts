import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Product, User } from './user';



const TOKEN_KEY = 'auth-token';
const USER_KEY = 'auth-user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseURL = "http://localhost:8080/api/v1/users";
  private base2URL = "http://localhost:8080/api/v1/login";
  private base3URL = "http://localhost:8080/api/v1/product";


  constructor(private httpClient: HttpClient) { }
  
  getUserList(): Observable<User[]>{
    return this.httpClient.get<User[]>(`${this.baseURL}`);
  }
  
  //register
  createUser(user: User): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, user);
  }

  getUserById(id: any): Observable<User>{
    return this.httpClient.get<User>(`${this.baseURL}/${id}`);
  }

  loginUser(user :User):Observable<object>{
    console.log(user)
    return this.httpClient.post(`${this.base2URL}`,user);
  }

  getProductById(id: any): Observable<Product>{
    
    return this.httpClient.get<Product>(`${this.base3URL}/${id}`);
   
  }
 
  getProductList(): Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.base3URL}`);
  }

}
