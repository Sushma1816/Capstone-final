import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product, User } from '../user';
import { UserService } from '../user.service';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';


@Component({
  selector: 'app-track-detail',
  templateUrl: './track-detail.component.html',
  styleUrls: ['./track-detail.component.css']
})
export class TrackDetailComponent implements OnInit {
  id: any;
  product: any;
  price: any;
  date: any;  
 
  // product:Product=new Product;
  flag: boolean = true;
  tableShow: boolean = false;
  user: User = new User;

  name: any;
  user_id:any;


  constructor(private userService: UserService, private fb: FormBuilder, private route: ActivatedRoute,
    private router: Router) { 
      this.name=localStorage.getItem( "user_id");
      this.user_id=JSON.parse(this.name);

      // this.user_id=localStorage.getItem( "name");
      // this.name=JSON.parse(this.user_id);
    }


  ngOnInit(): void { 
    
  }

  

  getProduct() {
    this.tableShow = true;
    this.userService.getProductById(this.id).subscribe(
      data => {
        this.product = data;
        this.flag = true;

      },
      err => this.flag = false
    );

  }

  logout(){
    localStorage.removeItem("user_id");
    localStorage.removeItem("password");
    localStorage.removeItem("name");
    this.ngOnInit();
  }
  
 
 

  
}
