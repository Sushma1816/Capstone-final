import { Component, OnInit } from '@angular/core';
 import { Router,ActivatedRoute } from '@angular/router';
import { Product, User } from '../user';
import { UserService } from '../user.service';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {



  id: any;
  product: any;
  price:any;
  date:any;
  
  // product:Product=new Product;
  flag: boolean = true;
  tableShow: boolean = false;
user:User=new User;

name:any;
  constructor(private userService: UserService, private fb: FormBuilder, private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {

  }
 
  get userName(): string {
    return this.userService.getUserList.name;
  }

  getProduct() {
    this.tableShow = true;
    this.userService.getProductById(this.id).subscribe(
      data => {
      this.product = data;
      this.flag = true;
      
    },
    err => this.flag = false
    );
  
  }
}

